var w = 800, h = 600;
var keyboard, sky, enemy, enemys, kalaban1, kalaban1s, car1, patong, pp, p, pp, pep, paw, eww, startText, buhay, buhays, kalaban, kalabans, motor, motors, kot, gameover, score, bestScore;

var titlepage;
var startButton;
var restartButton;
var playing = false;
var game = new Phaser.Game( w, h, Phaser.CANVAS, '');

var basicGame = function(){

}