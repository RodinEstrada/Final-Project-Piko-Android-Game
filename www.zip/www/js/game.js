var w = 800, h = 600;
var keyboard, sky, enemy, enemys, kalaban1, kalaban1s, car1, patong, pp, p, pp, pep, paw, eww, startText, buhay, buhays, kalaban, kalabans, motor, motors, kot, gameover, score, bestScore;

var titlepage;
var startButton;
var restartButton;
var playing = false;

var bounds = 15000;
var bone ,bones ,bonee, bonees ,boneee ,boneees ,boneeee ,boneeees ,boneeeee ,boneeeees;
var bato ,batos , batoo, batoos ,batooo , batooos; 
var gamepage;
var restartbutton  ,bestScore;
var score = 0;
var bg;
var about;
var aboutButton;
var insButton;
var startButton;
var x = 0 ;
var game = new Phaser.Game( w, h, Phaser.CANVAS, '');

game.state.add("bootGame", bootGame);
game.state.add("preloadGame", preloadGame);
game.state.add("menuGame", menuGame);
game.state.add("playGame", playGame);
game.state.add("winGame", playGame);
game.state.add("loseGame", loseGame);

game.state.start("bootGame");