
bootGame = {

		create:function(){
				game.physics.startSystem(Phaser.Physics.ARCADE);

                game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
                game.scale.forceLascape = true;
                game.scale.pageAlignHorizontally = true;
                game.scale.pageAlignVertically = true;
                // game.world.setBounds(0,0,800,1200);

			
				game.state.start("preloadGame");
				keyboard = game.input.keyboard.createCursorKeys();
		}
}

preloadGame = {
	preload:function(){
	       
        game.load.spritesheet('s', 'img/s.png',100,100);
        game.load.spritesheet('ss', 'img/ss.png',100,100);
        game.load.spritesheet('pauseButton','img/pause.png',34,0)
        game.load.spritesheet("start","img/startbut.png",250,0);
        game.load.spritesheet("button22","img/button22.png",200,0);

        game.load.image('car1', 'img/char.png');
        
        game.load.image('image4','img/bone.png');
        game.load.image('bonee','img/bonee.png');
        game.load.image('boneee','img/boneee.png');
        game.load.image('boneeee','img/boneeee.png');
        game.load.image('boneeeee','img/boneeeee.png');
        game.load.image('boneeeeee','img/boneeeeee.png');


        game.load.image('bato','img/bato.png');
        game.load.image('batoo','img/batoo.png');
        game.load.image('batooo','img/batooo.png');

        game.load.image('button1', 'img/button1.png');
        game.load.image('button2', 'img/button2.png');
        game.load.image('gameover','img/gameover1.png');
        game.load.image('menu','img/menu.png');
        game.load.image('about','img/aboutt.png');
        game.load.image('ins','img/ins.png');
        game.load.image('restart','img/restart.png',338,0);

        game.load.image('sky', 'img/way.png',800, 600);
        game.load.image('bg','img/bg.png');
        game.load.image('bout','img/about.png');
        game.load.image('inss','img/inss.png');

        game.load.image("pause","img/brick1.png");
        game.load.image("p","img/p.png");
        game.load.image("p","img/pp.png");
        game.load.image("patong","img/patong.png");
        game.load.image("pp","img/pp.png");
        game.load.image("pep","img/pep.png");
        game.load.image("paw","img/paw.png");
        game.load.image("eww","img/eww.png");

        // game.load.audio('talon','audio/toink.wav');
        game.load.audio('aw','audio/aw.wav');
        game.load.audio('kansyon1','audio/background.m4a');
        game.load.audio('kansyon','audio/rock.mp3');
        game.load.audio('patay','audio/spaceman.wav');
        game.load.audio('kuha','audio/pistol.wav');
	},

create:function(){

	    game.state.start("menuGame");
  }
}


menuGame = {
	create:function(){

		bg = game.add.sprite(0,0, "bg");
		startButton = game.add.button(300,290,'start', this.actionOnClick, this);
        aboutButton = game.add.button(300,350,'about', this.aboutOnClick, this);
        insButton = game.add.button(300,410,'ins', this.insOnClick, this);
        menu = game.add.image(200,170,"menu");
        menu.scale.x = 2;
        menu.scale.y = 1;
        startButton.scale.x = 2;
        startButton.scale.y = 1;
        aboutButton.scale.x = 2;
        aboutButton.scale.y = 1;
        insButton.scale.x = 2;
        insButton.scale.y = 1;
       


		console.log("current state: menu");

	},
	// update:function(){
	// 		if(keyboard.up.isDown){
	// 			game.state.start("playGame");
	// 		}
	// },

    actionOnClick: function(){
        
        startButton.destroy();
        game.state.start("playGame");

    },
     aboutOnClick: function(){
            aboutButton = game.add.image(0,0,"bout");
            restartButton=game.add.button(50,50,"button22",restartB,this);
            function restartB() {
            aboutButton.visible =! restartButton.visible;
            restartButton.destroy();

            window.location.href=window.location.href;
            }
        },
         insOnClick: function(){
            aboutButton = game.add.image(0,0,"inss");
            restartButton=game.add.button(50,50,"button22",restartB,this);
            function restartB() {
            aboutButton.visible =! restartButton.visible;
            restartButton.destroy();

            window.location.href=window.location.href;
            }
        },
    // actionOnClick: function(){
        
    //     about.destroy();
    //     game.state.start("playGame");

    // },

},


playGame = {
		create:function(){
			console.log("current state: play");

        kansyon =game.add.audio("kansyon",1,true);
        kansyon.Loop =true;
        kansyon.play();

        patay =game.add.audio("patay");
        kuha =game.add.audio("kuha");

		p = game.add.sprite(0,580,"p");
        p.scale.x = 2;
        game.physics.arcade.enable(p);
        p.body.immovable = true;

        patong = game.add.sprite(325,480,"patong");
        patong.scale.x = 4;
        game.physics.arcade.enable(patong);
        patong.body.immovable = true;

        pp = game.add.sprite(325,380,"pp");
        pp.scale.x = 4;
        game.physics.arcade.enable(pp);
        pp.body.immovable = true;

        pep = game.add.sprite(325,290,"pep");
        pep.scale.x = 4;
        game.physics.arcade.enable(pep);
        pep.body.immovable = true;

        paw = game.add.sprite(325,200,"paw");
        paw.scale.x = 3.5;
        game.physics.arcade.enable(paw);
        paw.body.immovable = true;

        eww = game.add.sprite(335,110,"eww");
        eww.scale.x = 3.5;
        game.physics.arcade.enable(eww);
        eww.body.immovable = true;

        sky = game.add.sprite(0,0,'sky');

        bone = game.add.group();
        bone.enableBody = true;
        this.createBones(0);

        bonee = game.add.group();
        bonee.enableBody = true;
        this.createBonees(0);

        boneee = game.add.group();
        boneee.enableBody = true;
        this.createBoneees(0);

        boneeee = game.add.group();
        boneeee.enableBody = true;
        this.createBoneeees(0);

        boneeeee = game.add.group();
        boneeeee.enableBody = true;
        this.createBoneeeees(0);

        boneeeeee = game.add.group();
        boneeeeee.enableBody = true;
        this.createBoneeeeees(0);

        bato = game.add.group();
        bato.enableBody = true;
        this.createBatos(1);
        bato.scale.x = 0.5;
        bato.scale.y = 0.5;

        batoo = game.add.group();
        batoo.enableBody = true;
        this.createBatoos(1);
        batoo.scale.x = 0.5;
        batoo.scale.y = 0.5;
       
        batooo = game.add.group();
        batooo.enableBody = true;
        this.createBatooos(1);
        batooo.scale.x = 0.5;
        batooo.scale.y = 0.5;

        car1 =  game.add.sprite(355,500,'car1');
        pause_label = game.add.image(900, 320, 'pause');

        game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
        game.scale.forcelLandscape = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;
        game.scale.setScreenSize = true;
   
        game.physics.startSystem(Phaser.Physics.ARCADE);
        game.physics.arcade.enable(car1);
        

        button = game.add.button(150,-500,'button1',this.pushRight);
        button = game.add.button(40,-500,'button2',this.pushLeft);
        button = game.add.button(660,495,'s',this.pushJump);
        button = game.add.button(50,495,'ss',this.pushDown);

        car1.body.collideWorldBounds = true;
        sky.animations.add('jump',[0,1,2],2,true);


        this.pauseButton = this.game.add.sprite(50,50, 'pauseButton');
        this.pauseButton.inputEnabled = true;
        this.pauseButton.events.onInputUp.add(function () {this.game.paused = true;},this);
        this.game.input.onDown.add(function () {if(this.game.paused)this.game.paused = false;},this); 
        
        
        keyboard = game.input.keyboard.createCursorKeys();

        car1.body.collideWorldBounds = true;
        car1.body.gravity.y = 10000;
        car1.body.bounce.y = .3
        car1.scale.y = 0.5;
        


        scoreText = game.add.text(650, 20, 'Score: 0', {fill: 'red'});
        // scoreText.scale.x = 2;
        // scoreText.scale.y = 2;
        // bestScore = game.add.text(650,50,'Best: '+this.retrieveBest(),{fill:'blue'});
        // bestScore.fixedToCamera = true;
        // bestScore = game.add.text(650, 50, "Best: " +this.getScore(),{ fill: 'blue'});
       


},

update:function () {
        game.physics.arcade.collide(car1,p);
        game.physics.arcade.collide(car1,patong);
        game.physics.arcade.collide(car1,pp);
        game.physics.arcade.collide(car1,pep);
        game.physics.arcade.collide(car1,paw);
        game.physics.arcade.collide(car1,eww);
        game.physics.arcade.collide(car1,bone,this.touchCar1);
        game.physics.arcade.collide(car1,bonee,this.touchCar1);
        game.physics.arcade.collide(car1,boneee,this.touchCar1);
        game.physics.arcade.collide(car1,boneeee,this.touchCar1);
        game.physics.arcade.collide(car1,boneeeee,this.touchCar1);
        game.physics.arcade.collide(car1,boneeeeee,this.touchCar1);
        game.physics.arcade.collide(car1,bato,this.touchBato);
        game.physics.arcade.collide(car1,batoo,this.touchBatoo);
        game.physics.arcade.collide(car1,batooo,this.touchBatooo);
        game.physics.arcade.collide(car1,bone);
        game.physics.arcade.collide(car1,bonee);
        game.physics.arcade.collide(car1,boneee);
        game.physics.arcade.collide(car1,boneeee);
        game.physics.arcade.collide(car1,boneeeee);
        game.physics.arcade.collide(car1,boneeeeee);
        game.physics.arcade.collide(car1,bato);
        game.physics.arcade.collide(car1,batoo);
        game.physics.arcade.collide(car1,batooo);

        

    if(keyboard.right.isDown){
        car1.body.velocity.x=210;
        car1.animations.stop();
        game.camera.y +=1;
}
    else if(keyboard.left.isDown){;
        car1.body.velocity.x=-210;
        game.camera.y +=1;
}

    else if(keyboard.up.isDown){
        car1.body.velocity.y=-210;
        game.camera.y +=1;
}
    else if(keyboard.down.isDown){
        car1.body.velocity.y=210;
        game.camera.y +=1;
}
    else{
        sky.animations.play('jump');
        car1.body.velocity.x=0;
        car1.body.velocity.y=0;
        game.camera.y +=1;
    }
},

        pushRight:function (){
            car1.animations.play('walk-right');
            car1.body.velocity.x=800;
        },
        pushLeft:function (){
            car1.animations.play('walk-left');
            car1.body.velocity.x=-800;

        },
        pushJump:function (){
            car1.animations.play('jump-up');
            car1.body.velocity.y=-7000;
            // talon = game.add.audio("talon",1,true);
            // talon.play();


        },
        pushDown:function (){
            car1.animations.play('jump-up');
            car1.body.velocity.y=7000;
            // talon = game.add.audio("talon",1,true);
            // talon.play();
        },
         touchCar1:function(car1,bone){
        car1.kill();
        game._paused = true
        patay.play();

        gamepage=game.add.image(0,0,"gameover");
    
        restartButton=game.add.button(250,450,"restart",restartB,this);
        function restartB() {
        gamepage.visible =! restartButton.visible;
        restartButton.destroy();

        window.location.href=window.location.href;
            }

    },
     touchCar1:function(car1,bonee){
        car1.kill();
        game._paused = true
        patay.play();
            kansyon.stop();

        gamepage=game.add.image(0,0,"gameover");
    
        restartButton=game.add.button(250,450,"restart",restartB,this);
        function restartB() {
        gamepage.visible =! restartButton.visible;
        restartButton.destroy();

        window.location.href=window.location.href;
            }

    },
     touchCar1:function(car1,boneee){
        car1.kill();
        game._paused = true
        patay.play();
            kansyon.stop();

        gamepage=game.add.image(0,0,"gameover");
    
        restartButton=game.add.button(250,450,"restart",restartB,this);
        function restartB() {
        gamepage.visible =! restartButton.visible;
        restartButton.destroy();

        window.location.href=window.location.href;
            }

    },
    touchCar1:function(car1,boneeee){
        car1.kill();
        game._paused = true
        patay.play();
            kansyon.stop();

        gamepage=game.add.image(0,0,"gameover");
    
        restartButton=game.add.button(250,450,"restart",restartB,this);
        function restartB() {
        gamepage.visible =! restartButton.visible;
        restartButton.destroy();

        window.location.href=window.location.href;
            }

    },
    touchCar1:function(car1,boneeeee){
        car1.kill();
        game._paused = true
        patay.play();
            kansyon.stop();

        gamepage=game.add.image(0,0,"gameover");
    
        restartButton=game.add.button(250,450,"restart",restartB,this);
        function restartB() {
        gamepage.visible =! restartButton.visible;
        restartButton.destroy();

        window.location.href=window.location.href;
            }

    },
    touchCar1:function(car1,boneeeeee){
        car1.kill();
        game._paused = true
        patay.play();
            kansyon.stop();

        gamepage=game.add.image(0,0,"gameover");
    
        restartButton=game.add.button(250,450,"restart",restartB,this);
        function restartB() {
        gamepage.visible =! restartButton.visible;
        restartButton.destroy();

        window.location.href=window.location.href;
            }

    },

         touchBato: function (car1,bato) {
        bato.kill();
        kuha.play();
        score +=1;

    //      if(getScore()<=a){
    //     this.saveScore(a);
    //     bestScoreText.text = "Best: "+a;
    // }

        scoreText.text = 'Score: ' + score;
    
},

 touchBatoo: function (car1,batoo) {
        batoo.kill();
        kuha.play();
        score +=1;

    //      if(getScore()<=a){
    //     this.saveScore(a);
    //     bestScoreText.text = "Best: "+a;
    // }

        scoreText.text = 'Score: ' + score;
    
},
touchBatooo: function (car1,batooo) {
        batooo.kill();
        kuha.play();
        score +=1;

    //      if(getScore()<=a){
    //     this.saveScore(a);
    //     bestScoreText.text = "Best: "+a;
    // }

        scoreText.text = 'Score: ' + score;
        
},

        

        createBones:function (time){
    setInterval(function(){
        
        bones = bone.create(0,70,'image4');
        bones.body.gravity.x = 500;
    },5000);

},   
        createBonees:function (time){
    setInterval(function(){
        
        bonees = bonee.create(0,230,'bonee');
        bonees.body.gravity.x = 500;
    },17000);

},   
        createBoneees:function (time){
    setInterval(function(){
        
        boneees = boneee.create(0,430,'boneee');
        boneees.body.gravity.x = 500;
    },8000);

},   
createBoneeees:function (time){
    setInterval(function(){
        
        boneeees = boneeee.create(810,150,'boneeee');
        boneeees.body.gravity.x = -500;
    },15000);

},   

createBoneeeees:function (time){
    setInterval(function(){
        
        boneeeees = boneeeee.create(700,330,'boneeeee');
        boneeeees.body.gravity.x = -500;
    },10000);

},   
createBoneeeeees:function (time){
    setInterval(function(){
        
        boneeeeees = boneeeeee.create(700,520,'boneeeeee');
        boneeeeees.body.gravity.x = -300;
    },25000);

},

 
    createBatos:function (time){
    setInterval(function(){
        
        batos = bato.create(0,80,'bato');
        batos.body.gravity.x = 800;
    },2000);

},
 createBatoos:function (time){
    setInterval(function(){
        
        batoos = batoo.create(0,430,'batoo');
        batoos.body.gravity.x = 800;
    },3000);

},
 createBatooos:function (time){
    setInterval(function(){
        
        batooos = batooo.create(0,900,'batooo');
        batooos.body.gravity.x = 800;
    },5000);

},
 restart: function() {
        window.location.href=window.location.href;
        stateText.visible = false;
},


 saveScore:function(score){
    localStorage.setItem("PikoData.com",score);
},

 getScore:function(){
    return (localStorage.getItem("PikoData.com") == null || localStorage.getItem("PikoData.com") == "")?0:
    localStorage.getItem("PikoData.com");
},



};


winGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}

loseGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}


