bootGame = {

		create:function(){
				game.physics.startSystem(Phaser.Physics.ARCADE);
				game.world.setBounds(0,0,bounds,0);
				game.state.start("preloadGame");
				keyboard = game.input.keyboard.createCursorKeys();
		}
}

preloadGame = {
	preload:function(){
	       game.load.image('car1', 'img/char.png');
        game.load.spritesheet('s', 'img/s.png',100,100);
        game.load.spritesheet('ss', 'img/ss.png',100,100);
    game.load.image('bg','img/bg.png');
        game.load.image('button1', 'img/button1.png');
        
        game.load.image("pause","img/brick1.png");
        game.load.image('button2', 'img/button2.png');
        
        game.load.image('sky', 'img/way.png',800, 600);
        game.load.image("p","img/p.png");
        game.load.image("p","img/pp.png");
        game.load.image("patong","img/patong.png");
        game.load.image("pp","img/pp.png");
        game.load.image("pep","img/pep.png");
        game.load.image("paw","img/paw.png");
        game.load.image("eww","img/eww.png");
          
	},

create:function(){

	    game.state.start("menuGame");
  }
}


menuGame = {
	create:function(){

		game.add.image(0,0,'bg');
		menuText = game.add.text(400,300, "Menu", {"fill":"#fff"});
		menuText.scale.x = 2;
		menuText.scale.y = 2;

		playText = game.add.text(400,400, "Play", {"fill":"#fff"});
		playText.scale.x = 2;
		playText.scale.y = 2;

		console.log("current state: menu");

	},
	update:function(){
			if(keyboard.up.isDown){
				game.state.start("playGame");
			}
	}

}


playGame = {
		create:function(){
			console.log("current state: play");
		  p = game.add.sprite(0,580,"p");
        p.scale.x = 2;
        game.physics.arcade.enable(p);
        p.body.immovable = true;

        patong = game.add.sprite(325,480,"patong");
        patong.scale.x = 4;
        game.physics.arcade.enable(patong);
        patong.body.immovable = true;

        pp = game.add.sprite(325,380,"pp");
        pp.scale.x = 4;
        game.physics.arcade.enable(pp);
        pp.body.immovable = true;

        pep = game.add.sprite(325,290,"pep");
        pep.scale.x = 4;
        game.physics.arcade.enable(pep);
        pep.body.immovable = true;

        paw = game.add.sprite(325,200,"paw");
        paw.scale.x = 3.5;
        game.physics.arcade.enable(paw);
        paw.body.immovable = true;

        eww = game.add.sprite(335,110,"eww");
        eww.scale.x = 3.5;
        game.physics.arcade.enable(eww);
        eww.body.immovable = true;

       sky = game.add.sprite(0,0,'sky');
       
        car1 =  game.add.sprite(355,500,'car1');
        pause_label = game.add.image(900, 320, 'pause');

        game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
        game.scale.forcelLandscape = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;
        game.scale.setScreenSize = true;
   
        game.physics.startSystem(Phaser.Physics.ARCADE);
        game.physics.arcade.enable(car1);
        

        button = game.add.button(150,500,'button1',this.pushRight);
        button = game.add.button(40,500,'button2',this.pushLeft);
        button = game.add.button(670,495,'s',this.pushJump);
        button = game.add.button(570,495,'ss',this.pushDown);

        car1.body.collideWorldBounds = true;
        sky.animations.add('jump',[0,1,2],2,true);


                pause_label.inputEnabled = true;
                pause_label.events.onInputUp.add(function () {
                    game.paused = true;
                });

            // game.input.onDown.add(this.unpause, self);
            // unpause:function (event){
            //     if(game.paused){ 
            //         pause_label.destroy();
            //         startText.visible=false;
            //             game.paused = false;
            //         }               
            // },            
        
        
        keyboard = game.input.keyboard.createCursorKeys();

        car1.body.collideWorldBounds = true;
        car1.body.gravity.y = 10000;
        car1.body.bounce.y = .3
        car1.scale.y = 0.5;
        


        score = game.add.text(650,10,'Score: 0',{fill:'red'});
        score.fixedToCamera = true;
        bestScore = game.add.text(650,50,'Best: '+this.retrieveBest(),{fill:'red'});
        bestScore.fixedToCamera = true;
       


},

update:function () {
        game.physics.arcade.collide(car1,p);
        game.physics.arcade.collide(car1,patong);
        game.physics.arcade.collide(car1,pp);
        game.physics.arcade.collide(car1,pep);
        game.physics.arcade.collide(car1,paw);
        game.physics.arcade.collide(car1,eww);

        

    if(keyboard.right.isDown){
        car1.body.velocity.x=210;
        car1.animations.stop();
        game.camera.y +=1;
}
    else if(keyboard.left.isDown){;
        car1.body.velocity.x=-210;
        game.camera.y +=1;
}

    else if(keyboard.up.isDown){
        car1.body.velocity.y=-210;
        game.camera.y +=1;
}
    else if(keyboard.down.isDown){
        car1.body.velocity.y=210;
        game.camera.y +=1;
}
    else{
        sky.animations.play('jump');
        car1.body.velocity.x=0;
        car1.body.velocity.y=0;
        game.camera.y +=1;
    }
},

        pushRight:function (){
            car1.animations.play('walk-right');
            car1.body.velocity.x=800;
        },
        pushLeft:function (){
            car1.animations.play('walk-left');
            car1.body.velocity.x=-800;

        },
        pushJump:function (){
            car1.animations.play('jump-up');
            car1.body.velocity.y=-7000;

        },
        pushDown:function (){
            car1.animations.play('jump-up');
            car1.body.velocity.y=7000;

        },
        retrieveBest:function (){
            return ((localStorage.getItem("gameStorage") != null) || (localStorage.getItem("gameStorage") != ""))?localStorage.getItem("gameStorage"):0;
        },

};


winGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}

loseGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}


